import os
import numpy as np

INPUT_SIZE = 4
OUTPUT_SIZE = 4
SEED = 1

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")
os.makedirs(DATA_DIR, exist_ok=True)

np.random.seed(SEED)

x = np.random.randint(-8, 8, size=(INPUT_SIZE,), dtype=np.int8)
W = np.random.randint(-8, 8, size=(OUTPUT_SIZE, INPUT_SIZE), dtype=np.int8)
b = np.random.randint(-20, 20, size=(OUTPUT_SIZE,), dtype=np.int32)

y = W.astype(np.int32) @ x.astype(np.int32) + b

def write_hex_8(filename, data):
    with open(os.path.join(DATA_DIR, filename), "w") as f:
        for val in data:
            f.write(f"{np.uint8(val):02X}\n")

def write_hex_32(filename, data):
    with open(os.path.join(DATA_DIR, filename), "w") as f:
        for val in data:
            f.write(f"{np.uint32(val):08X}\n")

write_hex_8("input_vec.hex", x)
write_hex_8("weights.hex", W.flatten())
write_hex_32("bias.hex", b)
write_hex_32("expected_output.hex", y)

print("Input vector x:")
print(x)
print("\nWeights W:")
print(W)
print("\nBias b:")
print(b)
print("\nExpected output y:")
print(y)
print(f"\nFiles written to: {DATA_DIR}")
