import os
import pandas as pd
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOC_IMG = os.path.join(ROOT, "docs", "images")
RESULTS = os.path.join(ROOT, "results")
os.makedirs(DOC_IMG, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)

# Replace these illustrative values with your actual Vivado and simulation results.
data = pd.DataFrame({
    "macs": [1, 2, 4, 8, 16],
    "cycles": [1000, 520, 270, 180, 155],
    "throughput_ops_per_cycle": [1.0, 1.9, 3.5, 5.2, 5.8],
    "dsp": [1, 2, 4, 8, 16],
    "lut": [300, 520, 980, 1800, 3600],
    "bram": [2, 2, 4, 6, 8],
    "max_freq_mhz": [180, 175, 165, 145, 120],
    "mac_utilization_percent": [100, 100, 95, 70, 42]
})

data.to_csv(os.path.join(RESULTS, "benchmark_results.csv"), index=False)

plots = [
    ("latency.png", "cycles", "Execution cycles", "Execution cycles vs MAC units"),
    ("throughput.png", "throughput_ops_per_cycle", "Throughput (ops/cycle)", "Throughput vs MAC units"),
    ("mac_utilization.png", "mac_utilization_percent", "MAC utilization (%)", "MAC utilization vs MAC units"),
    ("max_frequency.png", "max_freq_mhz", "Max frequency (MHz)", "Maximum frequency vs MAC units"),
]

for filename, ycol, ylabel, title in plots:
    plt.figure()
    plt.plot(data["macs"], data[ycol], marker="o")
    plt.xlabel("Number of MAC units")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.savefig(os.path.join(DOC_IMG, filename), bbox_inches="tight", dpi=150)
    plt.close()

plt.figure()
plt.plot(data["macs"], data["dsp"], marker="o", label="DSP")
plt.plot(data["macs"], data["lut"], marker="o", label="LUT")
plt.plot(data["macs"], data["bram"], marker="o", label="BRAM")
plt.xlabel("Number of MAC units")
plt.ylabel("Resource usage")
plt.title("Resource usage vs MAC units")
plt.grid(True)
plt.legend()
plt.savefig(os.path.join(DOC_IMG, "resource_usage.png"), bbox_inches="tight", dpi=150)
plt.close()

print(f"Graphs saved to: {DOC_IMG}")
print(f"CSV saved to: {os.path.join(RESULTS, 'benchmark_results.csv')}")
