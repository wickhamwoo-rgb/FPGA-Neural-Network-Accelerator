import os
import timeit
import numpy as np

INPUT_SIZE = 4
OUTPUT_SIZE = 4
FPGA_CLOCK_HZ = 100_000_000

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")


def hex8_to_int(v: str) -> int:
    value = int(v, 16)
    if value >= 128:
        value -= 256
    return value


def hex32_to_int(v: str) -> int:
    value = int(v, 16)
    if value >= 2**31:
        value -= 2**32
    return value


x_hex = np.loadtxt(os.path.join(DATA_DIR, "input_vec.hex"), dtype=str)
W_hex = np.loadtxt(os.path.join(DATA_DIR, "weights.hex"), dtype=str)
b_hex = np.loadtxt(os.path.join(DATA_DIR, "bias.hex"), dtype=str)

x = np.array([hex8_to_int(v) for v in x_hex], dtype=np.int32)
W = np.array([hex8_to_int(v) for v in W_hex], dtype=np.int32).reshape(OUTPUT_SIZE, INPUT_SIZE)
b = np.array([hex32_to_int(v) for v in b_hex], dtype=np.int32)


def cpu_dense_layer():
    return W @ x + b


cpu_time = timeit.timeit(cpu_dense_layer, number=10000) / 10000

# Replace these with cycle_count values printed by Vivado simulation.
single_mac_cycles = 24
parallel_4mac_cycles = 12

single_fpga_time = single_mac_cycles / FPGA_CLOCK_HZ
parallel_fpga_time = parallel_4mac_cycles / FPGA_CLOCK_HZ

print("CPU output:")
print(cpu_dense_layer())
print(f"Average CPU time: {cpu_time:.9e} seconds")
print(f"Estimated single-MAC FPGA time: {single_fpga_time:.9e} seconds")
print(f"Estimated 4-MAC FPGA time: {parallel_fpga_time:.9e} seconds")
print(f"Single-MAC speedup estimate: {cpu_time / single_fpga_time:.2f}x")
print(f"4-MAC speedup estimate: {cpu_time / parallel_fpga_time:.2f}x")
