# Conclusions

## Objective

The objective of this project was to investigate how increasing computational parallelism affects the performance of an FPGA-based neural network accelerator. Accelerator architectures with different numbers of parallel multiply-accumulate (MAC) units can be compared using the same inference workload.

## Key Findings

### 1. Parallelism reduces execution latency

Increasing the number of MAC units reduces the number of clock cycles needed to complete inference. The largest improvements are expected when scaling from a single-MAC design to small parallel configurations such as 2 or 4 MACs.

![Execution cycles vs MAC units](images/latency.png)

### 2. Throughput shows diminishing returns

Throughput improves as more MAC units are added, but the improvement is not expected to remain perfectly proportional. Once computation is no longer the only bottleneck, the throughput curve begins to flatten.

![Throughput vs MAC units](images/throughput.png)

### 3. Memory bandwidth limits scalability

A dense layer requires repeated movement of inputs, weights, and partial sums. As the number of MAC units increases, the accelerator requires more operands per clock cycle. If memory cannot supply these values quickly enough, some MAC units remain idle.

![MAC utilization vs MAC units](images/mac_utilization.png)

### 4. Hardware cost increases with parallelism

Using more MAC units increases DSP usage and may also increase LUT, BRAM, and routing resources. Larger designs may reduce the maximum achievable clock frequency due to longer routing paths and timing pressure.

![Resource usage vs MAC units](images/resource_usage.png)

![Maximum frequency vs MAC units](images/max_frequency.png)

## Engineering Implication

The main conclusion is that increasing computational resources alone does not guarantee proportional performance improvement. Effective FPGA accelerator design requires balancing compute parallelism, memory bandwidth, routing complexity, and timing closure.

## Future Work

Potential extensions include:

- Support for larger input and output sizes
- True parameterized MAC arrays using generate blocks
- Double-buffered BRAM to overlap memory loading and computation
- AXI interface for integration with a processor system
- INT4 quantized inference
- Convolutional neural network layer support
- Power and energy-efficiency analysis
