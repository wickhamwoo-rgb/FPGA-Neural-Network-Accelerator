# Future Work

Possible improvements:

1. Implement a fully parameterized MAC array using Verilog generate blocks.
2. Add BRAM double buffering to overlap computation and memory access.
3. Add support for larger neural network layers.
4. Integrate AXI-lite control registers for processor-based control.
5. Add UART or AXI-stream data movement for real FPGA hardware testing.
6. Compare INT8 and INT4 quantized inference.
7. Measure power and energy efficiency using Vivado power estimation.
