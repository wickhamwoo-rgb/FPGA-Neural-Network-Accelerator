# Methodology

## Verification Flow

1. Python generates random INT8 inputs and weights.
2. Python computes the golden reference output using NumPy.
3. Test vectors are written into `.hex` files.
4. Verilog loads the `.hex` files using `$readmemh`.
5. The FPGA accelerator computes its own output.
6. The testbench compares hardware output against the Python golden output.

## Performance Measurements

The project measures:

- Execution cycle count
- Estimated execution time
- Throughput
- DSP utilization
- LUT utilization
- BRAM utilization
- Maximum clock frequency
- MAC utilization

## Vivado Measurements

After synthesis and implementation, record:

- LUT usage from utilization report
- DSP usage from utilization report
- BRAM usage from utilization report
- Worst negative slack from timing report
- Maximum achievable clock frequency

## CPU Baseline

The Python benchmark script uses NumPy to compute the same dense layer. This provides a simple software comparison point.
