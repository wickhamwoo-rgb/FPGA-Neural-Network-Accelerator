# Architecture

## Dense Layer Operation

The accelerator computes a fully connected neural network layer:

```text
output[j] = bias[j] + Σ(input[i] × weight[j][i])
```

Each output neuron performs a dot product between the input vector and one row of the weight matrix.

## Baseline Architecture

The baseline design uses one MAC unit reused over multiple clock cycles.

```text
input_vec + weights
        ↓
     one MAC
        ↓
  accumulator
        ↓
 output_vec
```

This design uses fewer resources but takes more cycles.

## Parallel Architecture

The parallel version computes multiple input-weight products in the same clock cycle.

```text
x0*w0 ┐
x1*w1 ├── adder tree ── accumulator
x2*w2 ┤
x3*w3 ┘
```

This reduces cycle count but increases DSP/LUT usage and routing complexity.

## Key Trade-Off

Adding more MAC units improves arithmetic throughput, but only if the memory system can supply enough inputs and weights every cycle. If memory bandwidth is insufficient, some MAC units remain idle.
