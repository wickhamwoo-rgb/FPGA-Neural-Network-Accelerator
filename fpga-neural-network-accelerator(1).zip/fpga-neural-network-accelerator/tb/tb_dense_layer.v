`timescale 1ns/1ps

module tb_dense_layer;

    reg clk;
    reg rst;
    reg start;
    wire done;
    wire [31:0] cycle_count;

    integer i;
    integer errors;
    integer file;

    reg signed [31:0] expected [0:3];

    dense_layer #(
        .INPUT_SIZE(4),
        .OUTPUT_SIZE(4),
        .DATA_WIDTH(8),
        .ACC_WIDTH(32)
    ) uut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .done(done),
        .cycle_count(cycle_count)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("data/expected_output.hex", expected);

        clk = 0;
        rst = 1;
        start = 0;
        errors = 0;

        #20;
        rst = 0;

        #20;
        start = 1;
        #10;
        start = 0;

        wait(done);
        #20;

        file = $fopen("results/simulation_output.txt", "w");

        $display("Single-MAC dense layer completed.");
        $display("Cycle count = %0d", cycle_count);
        $fdisplay(file, "Single-MAC dense layer completed.");
        $fdisplay(file, "Cycle count = %0d", cycle_count);

        for (i = 0; i < 4; i = i + 1) begin
            $display("output[%0d] = %0d, expected = %0d", i, uut.output_vec[i], expected[i]);
            $fdisplay(file, "output[%0d] = %0d, expected = %0d", i, uut.output_vec[i], expected[i]);

            if (uut.output_vec[i] !== expected[i])
                errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TEST PASSED");
            $fdisplay(file, "TEST PASSED");
        end else begin
            $display("TEST FAILED with %0d errors", errors);
            $fdisplay(file, "TEST FAILED with %0d errors", errors);
        end

        $fclose(file);
        $stop;
    end

endmodule
