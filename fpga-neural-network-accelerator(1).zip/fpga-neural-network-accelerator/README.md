# Scalable FPGA Neural Network Accelerator

This project implements and evaluates a small INT8 neural network dense-layer accelerator using Verilog RTL. The goal is to investigate how increasing the number of parallel multiply-accumulate (MAC) units affects inference latency, throughput, and FPGA resource utilization.

## Project Goal

The main engineering question is:

> Does adding more MAC units always improve FPGA neural network inference performance?

The expected answer is no. Performance should improve at first, but eventually diminishing returns appear because of memory bandwidth, routing complexity, and resource constraints.

## Architecture

The project includes two accelerator versions:

| Design | Description |
|---|---|
| `dense_layer.v` | Baseline single-MAC dense layer accelerator |
| `dense_layer_parallel.v` | 4-MAC parallel dense layer accelerator |

Both designs compute:

```text
output = weights × input + bias
```

The accelerator uses:

- INT8 signed inputs and weights
- 32-bit signed accumulators
- FSM-based control logic
- Verilog memory arrays initialized from `.hex` files
- Python-generated golden reference outputs

## Repository Structure

```text
src/        Verilog RTL source files
tb/         Verilog testbenches
data/       Input, weight, bias, and expected-output hex files
scripts/    Python scripts for data generation, benchmarking, and graphs
docs/       Architecture, methodology, conclusions, and generated graphs
results/    Placeholder and measured benchmark/resource results
vivado/     Optional Vivado project files
```

## How to Run in Vivado

1. Create a new RTL project in Vivado.
2. Add the Verilog files in `src/` as design sources.
3. Add the testbench files in `tb/` as simulation sources.
4. Keep the repository root as the simulation working directory so `$readmemh("data/...")` can find the hex files.
5. Run Behavioral Simulation.
6. Confirm that the console prints `TEST PASSED`.
7. Run synthesis and implementation to collect LUT, DSP, BRAM, and timing results.

## Generate New Test Data

From the repository root:

```bash
python scripts/generate_nn_data.py
```

This creates:

```text
data/input_vec.hex
data/weights.hex
data/bias.hex
data/expected_output.hex
```

## Generate Placeholder Graphs

```bash
python scripts/generate_placeholder_graphs.py
```

This creates graphs in:

```text
docs/images/
```

Replace the placeholder values in the script with actual Vivado results once the project is synthesized.

## Current Results Template

| MAC Units | Cycles | DSP | LUT | BRAM | Max Frequency |
|---:|---:|---:|---:|---:|---:|
| 1 | TBD | TBD | TBD | TBD | TBD |
| 4 | TBD | TBD | TBD | TBD | TBD |
| 8 | TBD | TBD | TBD | TBD | TBD |
| 16 | TBD | TBD | TBD | TBD | TBD |

## Conclusion Summary

This project demonstrates that accelerator performance is not determined only by the number of MAC units. Increasing parallelism reduces arithmetic latency, but larger designs eventually face diminishing returns due to memory bandwidth, routing congestion, and FPGA resource limits.

See [`docs/conclusions.md`](docs/conclusions.md) for the full analysis.
