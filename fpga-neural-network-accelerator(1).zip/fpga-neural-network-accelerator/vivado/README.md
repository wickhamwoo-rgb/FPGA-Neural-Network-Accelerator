# Vivado Notes

This folder can hold your Vivado project files if you choose to commit them.

Recommended workflow:

1. Create a new RTL project in Vivado.
2. Add files from `../src` as design sources.
3. Add files from `../tb` as simulation sources.
4. Run Behavioral Simulation.
5. Run Synthesis and Implementation.
6. Save utilization and timing reports into `../results`.

You do not need to commit large Vivado generated folders such as `.runs`, `.sim`, or `.cache`.
