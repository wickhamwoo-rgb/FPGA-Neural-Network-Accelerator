# Resource Utilization Results

Replace the placeholder values below with Vivado synthesis results.

| Design | MAC Units | LUT | FF | DSP | BRAM | Max Frequency |
|---|---:|---:|---:|---:|---:|---:|
| Baseline | 1 | TBD | TBD | TBD | TBD | TBD |
| Parallel | 4 | TBD | TBD | TBD | TBD | TBD |
