# Timing Results

Record timing after synthesis and implementation.

| Design | Target Clock | WNS | Timing Met? | Estimated Max Frequency |
|---|---:|---:|---|---:|
| Baseline | 100 MHz | TBD | TBD | TBD |
| Parallel | 100 MHz | TBD | TBD | TBD |
