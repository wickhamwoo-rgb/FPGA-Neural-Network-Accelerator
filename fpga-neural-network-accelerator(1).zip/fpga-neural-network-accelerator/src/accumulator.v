// accumulator.v
// Simple signed accumulator block.

module accumulator #(
    parameter ACC_WIDTH = 32
)(
    input clk,
    input rst,
    input clear,
    input en,
    input signed [ACC_WIDTH-1:0] data_in,
    input signed [ACC_WIDTH-1:0] bias,
    output reg signed [ACC_WIDTH-1:0] acc_out
);

    always @(posedge clk) begin
        if (rst)
            acc_out <= 0;
        else if (clear)
            acc_out <= bias;
        else if (en)
            acc_out <= acc_out + data_in;
    end

endmodule
