// mac_unit.v
// Signed multiply-accumulate unit for INT8 neural network inference.

module mac_unit #(
    parameter DATA_WIDTH = 8,
    parameter ACC_WIDTH  = 32
)(
    input clk,
    input rst,
    input en,
    input clear,

    input  signed [DATA_WIDTH-1:0] a,
    input  signed [DATA_WIDTH-1:0] b,
    input  signed [ACC_WIDTH-1:0] bias,

    output reg signed [ACC_WIDTH-1:0] acc
);

    always @(posedge clk) begin
        if (rst) begin
            acc <= 0;
        end else if (clear) begin
            acc <= bias;
        end else if (en) begin
            acc <= acc + (a * b);
        end
    end

endmodule
