// dense_layer.v
// Baseline single-MAC INT8 dense layer accelerator.
// Computes: output_vec = weights * input_vec + bias

module dense_layer #(
    parameter INPUT_SIZE  = 4,
    parameter OUTPUT_SIZE = 4,
    parameter DATA_WIDTH  = 8,
    parameter ACC_WIDTH   = 32
)(
    input clk,
    input rst,
    input start,

    output reg done,
    output reg [31:0] cycle_count
);

    reg signed [DATA_WIDTH-1:0] input_vec [0:INPUT_SIZE-1];
    reg signed [DATA_WIDTH-1:0] weights   [0:INPUT_SIZE*OUTPUT_SIZE-1];
    reg signed [ACC_WIDTH-1:0]  bias      [0:OUTPUT_SIZE-1];
    reg signed [ACC_WIDTH-1:0]  output_vec[0:OUTPUT_SIZE-1];

    reg [7:0] out_idx;
    reg [7:0] in_idx;
    reg signed [ACC_WIDTH-1:0] acc;
    reg [2:0] state;

    localparam IDLE    = 3'd0;
    localparam INIT    = 3'd1;
    localparam COMPUTE = 3'd2;
    localparam STORE   = 3'd3;
    localparam NEXT    = 3'd4;
    localparam DONE    = 3'd5;

    wire signed [DATA_WIDTH-1:0] x_val;
    wire signed [DATA_WIDTH-1:0] w_val;

    assign x_val = input_vec[in_idx];
    assign w_val = weights[out_idx*INPUT_SIZE + in_idx];

    initial begin
        $readmemh("data/input_vec.hex", input_vec);
        $readmemh("data/weights.hex", weights);
        $readmemh("data/bias.hex", bias);
    end

    always @(posedge clk) begin
        if (rst) begin
            out_idx <= 0;
            in_idx <= 0;
            acc <= 0;
            done <= 0;
            cycle_count <= 0;
            state <= IDLE;
        end else begin
            if (state != IDLE && state != DONE)
                cycle_count <= cycle_count + 1;

            case (state)
                IDLE: begin
                    done <= 0;
                    cycle_count <= 0;
                    if (start) begin
                        out_idx <= 0;
                        in_idx <= 0;
                        acc <= 0;
                        state <= INIT;
                    end
                end

                INIT: begin
                    acc <= bias[out_idx];
                    in_idx <= 0;
                    state <= COMPUTE;
                end

                COMPUTE: begin
                    acc <= acc + (x_val * w_val);
                    if (in_idx == INPUT_SIZE - 1)
                        state <= STORE;
                    else
                        in_idx <= in_idx + 1;
                end

                STORE: begin
                    output_vec[out_idx] <= acc;
                    state <= NEXT;
                end

                NEXT: begin
                    if (out_idx == OUTPUT_SIZE - 1)
                        state <= DONE;
                    else begin
                        out_idx <= out_idx + 1;
                        state <= INIT;
                    end
                end

                DONE: begin
                    done <= 1;
                    state <= DONE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
