// fsm_controller.v
// Placeholder/example FSM controller file.
// The current accelerators implement their FSM internally for simplicity.
// This file is included to show how the design could be refactored into
// separate control and datapath modules in a larger project.

module fsm_controller(
    input clk,
    input rst,
    input start,
    output reg done
);

    reg [1:0] state;

    localparam IDLE = 2'd0;
    localparam RUN  = 2'd1;
    localparam DONE = 2'd2;

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            done <= 0;
        end else begin
            case (state)
                IDLE: begin
                    done <= 0;
                    if (start)
                        state <= RUN;
                end

                RUN: begin
                    // Replace with real completion condition when separated.
                    state <= DONE;
                end

                DONE: begin
                    done <= 1;
                    state <= DONE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
